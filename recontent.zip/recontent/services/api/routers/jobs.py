from fastapi import APIRouter
from google.cloud import pubsub_v1
import json
from packages.common.config import PUBSUB_TOPIC_JOBS, GOOGLE_CLOUD_PROJECT
from packages.common.schemas import CompositeJob

router = APIRouter()
publisher = pubsub_v1.PublisherClient()
topic_path = publisher.topic_path(GOOGLE_CLOUD_PROJECT, PUBSUB_TOPIC_JOBS)

@router.post("/jobs/composite")
def jobs_composite(job: CompositeJob):
    publisher.publish(topic_path, data=json.dumps(job.model_dump()).encode("utf-8"))
    return {"status": "queued"}
