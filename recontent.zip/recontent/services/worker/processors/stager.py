# Placeholder for Imagen inpainting path (mask insertion) — implement when masks are uploaded
def run(job: dict) -> list[str]:
    return []
