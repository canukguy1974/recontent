# Stubs; fill with real API calls for IG/FB/LinkedIn/X/TikTok
def run(post: dict) -> dict:
    return {"status": "published", "external_id": "stub-123"}
