Write a neutral, professional caption (180–220 chars) with 3–5 neutral hashtags.
If staged=true, append: “One or more photos are virtually staged.”
