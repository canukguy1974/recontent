Use the provided mask as the placement zone. Do not modify architecture. Style: Scandinavian 84" sofa, walnut coffee table, low-pile rug; neutral color; contact shadows. Return 3 variants.
