Validate per org policy: disclosure present if staged; consent present if people appear; MLS profile rules (people allowed? non-staged companion?);
IG JPEG + aspect ratios. Return pass/fail and fixes.
