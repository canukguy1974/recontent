Check org weekly quota and platform limits (e.g., Instagram content_publishing_limit). Publish, store external IDs, handle retries with backoff, reschedule on rate-limit.
